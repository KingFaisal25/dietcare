<?php

namespace App\Exceptions;

use Exception;

/**
 * Exception thrown when authentication fails.
 */
class AuthenticationException extends Exception
{
    public function __construct(string $message = 'Authentication failed.', int $code = 401, ?\Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }
}
