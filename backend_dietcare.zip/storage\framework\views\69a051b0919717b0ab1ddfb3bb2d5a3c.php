<?php $__env->startComponent('mail::message'); ?>
# Order Confirmation

Hi <?php echo e($order->user->name); ?>,

Thank you for your order! Your payment has been successfully processed.

**Order Details:**
- **Order Code:** <?php echo e($order->order_code); ?>

- **Program:** <?php echo e($order->program->name); ?>

- **Nutritionist:** <?php echo e($order->nutritionist->name); ?>

- **Total Amount:** Rp <?php echo e(number_format($order->total_amount, 2, ',', '.')); ?>

- **Paid At:** <?php echo e($order->paid_at->format('d F Y H:i')); ?>


You can now start your consultation with the nutritionist.

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\dietcaresalma\resources\views\emails\orders\confirmation.blade.php ENDPATH**/ ?>